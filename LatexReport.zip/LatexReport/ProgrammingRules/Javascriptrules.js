// The follwowing code shows an example of these rules.
// Declaration of variables & passing a function name.

var container = document.getElementById('container');
for(var i = 0, len = someArray.length; i < len;  i++) {
   container.innerHtml += 'my number: ' + i;
   console.log(i);
}

setInterval(someFunction, 3000);
